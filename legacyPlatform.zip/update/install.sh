#!/bin/sh
rm -R /System/Library/UserEventPlugins/com.apple.telemetry.plugin
