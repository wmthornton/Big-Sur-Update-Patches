#!/bin/sh
cp -R LegacyUSBInjector.kext /Library/Extensions
chmod -R 755 /Library/Extensions/LegacyUSBInjector.kext
chown -R 0:0 /Library/Extensions/LegacyUSBInjector.kext

cp -R LegacyUSBVideoSupport.kext /Library/Extensions
chmod -R 755 /Library/Extensions/LegacyUSBVideoSupport.kext
chown -R 0:0 /Library/Extensions/LegacyUSBVideoSupport.kext
