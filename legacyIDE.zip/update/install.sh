#!/bin/sh
cp AppleIntelPIIXATA.kext /System/Library/Extensions/IOATAFamily.kext/Contents/PlugIns
chmod -R 755 /System/Library/Extensions/IOATAFamily.kext
chown -R 0:0 /System/Library/Extensions/IOATAFamily.kext
