#!/bin/sh
cp -R AppleUSBTopCase.kext /System/Library/Extensions
chmod -R 755 /System/Library/Extensions/AppleUSBTopCase.kext
chown -R 0:0 /System/Library/Extensions/AppleUSBTopCase.kext
cp -R Trackpad.prefPane /System/Library/PreferencePanes/
chmod -R 755 /System/Library/PreferencePanes/Trackpad.prefPane
chown -R 0:0 /System/Library/PreferencePanes/Trackpad.prefPane
