#!/bin/sh
if [ ! -d ~/Bklt_Backup ]; then
    mkdir ~/Bklt_Backup
    cp -R /System/Library/PrivateFrameworks/DisplayServices.framework ~/Bklt_Backup
    cp -R /System/Library/Extensions/AppleBacklight.kext ~/Bklt_Backup
    cp -R /System/Library/Extensions/AppleBacklightExpert.kext ~/Bklt_Backup
    cp -R /System/Library/Extensions/AppleGraphicsControl.kext/Contents/PlugIns/AGDCBacklightControl.kext ~/Bklt_Backup
fi
rm -R /System/Library/Extensions/AppleGraphicsControl.kext/Contents/PlugIns/AGDCBacklightControl.kext
cp -R DisplayServices.framework /System/Library/PrivateFrameworks
cp -R AppleBacklight.kext /System/Library/Extensions
cp -R AppleBacklightExpert.kext /System/Library/Extensions
chmod -R 755 /System/Library/PrivateFrameworks/DisplayServices.framework
chown -R 0:0 /System/Library/PrivateFrameworks/DisplayServices.framework
chmod -R 755 /System/Library/Extensions/AppleBacklight.kext
chown -R 0:0 /System/Library/Extensions/AppleBacklight.kext
chmod -R 755 /System/Library/Extensions/AppleBacklightExpert.kext
chown -R 0:0 /System/Library/Extensions/AppleBacklightExpert.kext
