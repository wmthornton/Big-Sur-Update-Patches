#!/bin/sh
cp -R SIPManager.kext /Library/Extensions
chmod -R 755 /Library/Extensions/SIPManager.kext
chown -R 0:0 /Library/Extensions/SIPManager.kext
