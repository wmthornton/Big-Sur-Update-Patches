#!/bin/sh
if [ ! -d ~/CoreBrightness-backup ]; then
    mkdir ~/CoreBrightness-backup
    cp -R /System/Library/PrivateFrameworks/CoreBrightness.framework ~/CoreBrightness-backup
fi
cp CoreBrightness /System/Library/PrivateFrameworks/CoreBrightness.framework/Versions/A
chown -R 0:0 /System/Library/PrivateFrameworks/CoreBrightness.framework
chmod -R 755 /System/Library/PrivateFrameworks/CoreBrightness.framework
