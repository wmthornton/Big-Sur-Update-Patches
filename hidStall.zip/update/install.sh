#!/bin/sh
cp IOHIDFamily /System/Library/Extensions/IOHIDFamily.kext/Contents/MacOS
chmod -R 755 /System/Library/Extensions/IOHIDFamily.kext
chown -R 0:0 /System/Library/Extensions/IOHIDFamily.kext
