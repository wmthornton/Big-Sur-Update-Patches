#!/bin/sh
cp -R AAAMouSSE.kext /Library/Extensions

chmod -R 755 /Library/Extensions/AAAMouSSE.kext
chown -R 0:0 /Library/Extensions/AAAMouSSE.kext

